import React from 'react';

 import { BrowserRouter as Router,Route, Switch, Link} from "react-router-dom";

// import logo from './logo.svg';
 import './App.css';
//  import oppcard from './components/browseopp/oppcard';
import Browseopp from './pages/Browseopp';

//  import Header from './components/Header';
import Home2 from './pages/Home2';
import Footer2 from './components/footer2';
import Navigation from './components/Navigation';
import Contact from './pages/Contact';
import Aboutus from './pages/Aboutus';
import Singleopp from './pages/Singleopp';
import Postopportunity from './pages/Postopportunity';
import Singleopp2 from './pages/Singleopp2';
import Browseopp2 from './pages/Browseopp2';

    function App() {
      return (
    
        // <Router>
        //   <Navigation/>
        //     <Switch>
        //       <Route exact path="/">
        //         <Home />
        //       </Route>
        //       <Route path="/about">
        //         <About />
        //       </Route>
        //       <Route path="/contact">
        //         <Contact />
        //       </Route>
        //       <Route path="/form">
        //         <Form />
        //       </Route>
        //       <Route path="/display/:text">
        //         <Display/>
        //       </Route>
        //     </Switch>
        // </Router>
    
        <Router>
          <Navigation/>
           {/* <Header/>  */}
            
          
            <Switch>
              <Route exact path="/">
                 <Home2 /> 
             </Route> 
              <Route path="/browseopp"> 
              <Browseopp2/> 
              </Route> 
              <Route path="/contactus">
                 <Contact />
               </Route>

               <Route path="/aboutus">
                 <Aboutus />
               </Route>

               <Route path="/singleopp">
                 <Singleopp2/>
               </Route>

               <Route path="/postopp">
                 <Postopportunity/>
               </Route>

               

            </Switch>
            <Footer2/>
        </Router>
     
      );
    
      }
    
    export default App;



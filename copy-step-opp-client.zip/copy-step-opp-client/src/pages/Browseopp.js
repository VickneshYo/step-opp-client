import React from 'react'
// import { BrowserRouter as Router,Route, Switch, Link} from "react-router-dom";

import { Image } from 'react-bootstrap';
import Button from 'react-bootstrap/Button'
import Card from 'react-bootstrap/Card'
import DropdownButton from 'react-bootstrap/DropdownButton'
import Dropdown from 'react-bootstrap/Dropdown'
import Pagination from 'react-bootstrap/Pagination'
import opp5 from '../Photos/opp5.jpg';
import Nav from 'react-bootstrap/Nav';
// import Header from '../components/Header';


export default function Browseopp() {
    return (
    <div className="body1">
      <div>
      <h1 className="header"><b> Browse Opportunities </b></h1>
      </div>
    <div className="row">

    <div className= 'col-lg-3 filter-dropdown'>
    <DropdownButton id="dropdown-item-button" title="Opportunity Category">
    <Dropdown.ItemText> Workshops</Dropdown.ItemText>
    <Dropdown.Item as="button"> Conferences </Dropdown.Item>
    <Dropdown.Item as="button"> Jobs </Dropdown.Item>
    <Dropdown.Item as="button"> Challenges </Dropdown.Item>
    </DropdownButton>
    </div>
    
    <div className= 'col-lg-3 filter-dropdown'>
    <DropdownButton id="dropdown-item-button" title="Customer Category">
    <Dropdown.ItemText> School leavers </Dropdown.ItemText>
    <Dropdown.Item as="button"> Under graduates </Dropdown.Item>
    <Dropdown.Item as="button"> Graduates </Dropdown.Item>
    
    </DropdownButton>
    </div>

<div className= 'col-lg-3 filter-dropdown'>
<DropdownButton id="dropdown-item-button" title="Location">
  <Dropdown.ItemText>Dropdown item text</Dropdown.ItemText>
  <Dropdown.Item as="button">Action</Dropdown.Item>
  <Dropdown.Item as="button">Another action</Dropdown.Item>
  <Dropdown.Item as="button">Something else</Dropdown.Item>
</DropdownButton>
</div>

<div className= 'col-lg-3 filter-dropdown'>
<DropdownButton id="dropdown-item-button" title="Deadline">
  <Dropdown.ItemText>Dropdown item text</Dropdown.ItemText>
  <Dropdown.Item as="button">Action</Dropdown.Item>
  <Dropdown.Item as="button">Another action</Dropdown.Item>
  <Dropdown.Item as="button">Something else</Dropdown.Item>
</DropdownButton>
</div>
</div>   

<div className="row">
    <div className= 'col-lg-3'>
    <button variant="primary" className="filter explore" id="filter-explore"> Explore </button>
    </div>

    <div className= 'col-lg-3'>
    <button variant="primary" className="filter reset" id="filter-reset"> Reset Filter </button>
    </div>
</div>

  <div className='container mt-5'>
    <div className='row'>
      <div className= 'col-lg-3 section-second'>
      <Card style={{ width: '18rem' }} className="image-card">
      
      <Card.Img variant="top" src={opp5} />
   
      <Card.Body>
      <Card.Title>Competition</Card.Title>
      <Card.Text>
      Some quick example text to build on the card title and make up the bulk of
      the card's content.
      </Card.Text>
      <Nav.Link  to='/' className="home" href="/singleopp">
      <Button variant="primary" className="opp-button">Opportunity 1</Button>
      </Nav.Link>
    </Card.Body>
    </Card>  
{/* <button className='xyz'>View</button> */}
    </div>


 <div className= 'col-lg-3 section-second-1'>
  <Card style={{ width: '18rem' }} className="image-card">
  <Card.Img variant="top" src={opp5} />
  <Card.Body>
    <Card.Title> Challenges </Card.Title>
    <Card.Text>
      Some quick example text to build on the card title and make up the bulk of
      the card's content.
    </Card.Text>
    <Button variant="primary" className="opp-button">Opportunity 2</Button>
    
  </Card.Body>
</Card>  
</div>
                <div className= 'col-lg-3 section-second-2'>
                <Card style={{ width: '18rem' }} className="image-card">
  <Card.Img variant="top" src={opp5} />
  <Card.Body>
    <Card.Title> Jobs </Card.Title>
    <Card.Text>
      Some quick example text to build on the card title and make up the bulk of
      the card's content.
    </Card.Text>
    <Button variant="primary" className="opp-button">Opportunity 3</Button>
    
  </Card.Body>
</Card>  
</div>
</div>
       

            <div className='row'>
                <div className= 'col-lg-3 section-second'>
                <Card style={{ width: '18rem' }} className="image-card">
  <Card.Img variant="top" src={opp5} />
  <Card.Body>
    <Card.Title>Card Title</Card.Title>
    <Card.Text>
      Some quick example text to build on the card title and make up the bulk of
      the card's content.
    </Card.Text>
    <Button variant="primary" className="opp-button">Opportunity 4</Button>
    
  </Card.Body>
</Card>  
</div>
                <div className= 'col-lg-3 section-second-1'>
                <Card style={{ width: '18rem' }} className="image-card">
  <Card.Img variant="top" src={opp5} />
  <Card.Body>
    <Card.Title>Card Title</Card.Title>
    <Card.Text>
      Some quick example text to build on the card title and make up the bulk of
      the card's content.
    </Card.Text>
    <Button variant="primary" className="opp-button">Opportunity 5</Button>
   
  </Card.Body>
</Card>  
</div>
                <div className= 'col-lg-3 section-second-2'>
                <Card style={{ width: '18rem' }} className="image-card">
  <Card.Img variant="top" src={opp5} />
  <Card.Body>
    <Card.Title>Card Title</Card.Title>
    <Card.Text>
      Some quick example text to build on the card title and make up the bulk of
      the card's content.
    </Card.Text>
    <Button variant="primary" className="opp-button">Opportunity 6</Button>
    
  </Card.Body>
</Card>  
</div>
         
</div>
            

            <div className='row'>
                <div className= 'col-lg-3 section-second'>
                <Card style={{ width: '18rem' }} className="image-card">
  <Card.Img variant="top" src={opp5} />
  <Card.Body>
    <Card.Title>Card Title</Card.Title>
    <Card.Text>
      Some quick example text to build on the card title and make up the bulk of
      the card's content.
    </Card.Text>
    <Button variant="primary" className="opp-button">Opportunity 7</Button>
    
  </Card.Body>
</Card>  
</div>
                <div className= 'col-lg-3 section-second-1'>
                <Card style={{ width: '18rem' }} className="image-card">
  <Card.Img variant="top" src={opp5} />
  <Card.Body>
    <Card.Title>Card Title</Card.Title>
    <Card.Text>
      Some quick example text to build on the card title and make up the bulk of
      the card's content.
    </Card.Text>
    <Button variant="primary" className="opp-button">Opportunity 8</Button>
    
  </Card.Body>
</Card>  
</div>
                <div className= 'col-lg-3 section-second-2'>
                <Card style={{ width: '18rem' }} className="image-card">
  <Card.Img variant="top" src={opp5} />
  <Card.Body>
    <Card.Title>Card Title</Card.Title>
    <Card.Text>
      Some quick example text to build on the card title and make up the bulk of
      the card's content.
    </Card.Text>
    <Button variant="primary" className="opp-button">Opportunity 9</Button>
    
  </Card.Body>
</Card>  
</div>

            </div>

           
        </div>
        <div>
        <Pagination className="pagi" id="pagi">
  <Pagination.First />
  <Pagination.Prev />
  <Pagination.Item>{1}</Pagination.Item>
  <Pagination.Ellipsis />

  <Pagination.Item>{5}</Pagination.Item>
  <Pagination.Item>{6}</Pagination.Item>
  <Pagination.Item active>{7}</Pagination.Item>
  <Pagination.Item>{8}</Pagination.Item>
  <Pagination.Item disabled>{9}</Pagination.Item>

  <Pagination.Ellipsis />
  <Pagination.Item>{10}</Pagination.Item>
  <Pagination.Next />
  <Pagination.Last />
</Pagination>
</div>
        </div>

    )
}


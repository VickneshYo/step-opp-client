// import React from 'react';
// import { Form } from 'react-bootstrap';

// import Button from '@restart/ui/esm/Button';

// import { Col } from 'react-bootstrap';

// import { Row } from 'react-bootstrap';

// import { Alert } from 'react-bootstrap';



// ​

// export default function Postopportunity() {
//     return (
//         <div>
//                         <div className ="top">

// <center> <h2>Post an Opportunity</h2></center> 

// </div>

// ​

// <div classname="alert">

// <Alert variant="dark">

// <Alert.Heading><b>Hey, nice to see you </b></Alert.Heading>

// <p>

// Have any opportunity that you would like to share with STEP Opps community?

// Please use this form to inform us about it. You can also mail us at stepopps@gmail.com.

// </p>

// <hr />

// <p className="mb-0">

// By submitting opportunity to us, you are agreeing to these terms. Please read them carefully.

// <br /><br />

// 1.Information provided here is true and do not contain confidential information which would in anyway harm the concerned or other organization. Authenticity, validity and reliability of information shared are also ensured and the submitter takes full responsibilities of these,

// ​

// </p>

// </Alert>

// </div>

// ​

// ​

// <Form>

// ​

// ​

// <Form.Group as={Row} className="mb-3" controlId="formHorizontalDescription">

// <Form.Label column sm={2}>

// Description

// </Form.Label>

// <Col sm={5}>

// <Form.Control type="description" placeholder="Enter Description" />

// </Col>

// </Form.Group>

// ​

// <fieldset>

// <Form.Group as={Row} className="mb-3" controlId="formHorizontalDescription">

// <Form.Label column sm={2}>

// Opportunity type

// </Form.Label>



// <Col sm={5}>

// <Dropdown>

// <Dropdown.Toggle id="dropdown-button-dark-example1" variant="secondary">

// Select type

// </Dropdown.Toggle>

// ​

// <Dropdown.Menu variant="dark">

// <Dropdown.Item href="#/action-1" active>

// Jobs

// </Dropdown.Item>

// <Dropdown.Item href="#/action-2">Scholarships</Dropdown.Item>

// <Dropdown.Item href="#/action-3">Competitions</Dropdown.Item>

// <Dropdown.Item href="#/action-4">Workshops</Dropdown.Item>

// </Dropdown.Menu>

// </Dropdown>

// </Col>

// </Form.Group>

// </fieldset>

// <br />

// ​

// <fieldset>

// <Form.Group as={Row} className="mb-3">

// <Form.Label as="legend" column sm={2}>

// Funding Type

// </Form.Label>

// <Col sm={10}>

// <Form.Check

// type="radio"

// label="Fully funded"

// name="formHorizontalRadios"

// id="formHorizontalRadios1"

// />

// <Form.Check

// type="radio"

// label="Partially funded"

// name="formHorizontalRadios"

// id="formHorizontalRadios2"

// />



// </Col>

// </Form.Group>

// </fieldset>

// ​

// <fieldset>

// <Form.Group as={Row} className="mb-3">

// <Form.Label as="legend" column sm={2}>

// Category

// </Form.Label>

// <Col sm={10}>

// <Form.Check

// type="radio"

// label="Customer"

// name="formHorizontalRadios"

// id="formHorizontalRadios1"

// />

// <Form.Check

// type="radio"

// label="Opportunity Provider"

// name="formHorizontalRadios"

// id="formHorizontalRadios2"

// />



// </Col>

// </Form.Group>

// </fieldset>

// ​

// <Form.Group className="mb-3" controlId="exampleForm.ControlTextarea1">

// <Form.Label>Benefits</Form.Label>

// <Col sm={5}>



// <Form.Control as="textarea" rows={3} />

// </Col>



// </Form.Group>

// ​



// ​

// ​

// ​

// <Form.Group as={Row} className="mb-3" controlId="formHorizontalapplylink">

// <Form.Label column sm={2}>

// Apply link

// </Form.Label>

// <Col sm={5}>

// <Form.Control type="applylink" />

// </Col>

// </Form.Group>

// ​

// ​

// <Form.Group as={Row} className="mb-3" controlId="formHorizontaldeadline">

// <Form.Label column sm={2}>

// Deadline

// </Form.Label>

// <Col sm={5}>

// <Form.Control type="deadline" />

// </Col>

// </Form.Group>

// ​

// ​

// <Form.Group className="mb-3" controlId="exampleForm.ControlTextarea2">

// <Form.Label>For further deatails</Form.Label>

// <Col sm={5}>

// <Form.Control as="textarea" rows={3} />

// </Col>

// </Form.Group>

// ​

// ​

// <Form.Group as={Row} className="mb-3" controlId="formHorizontaldeadline">

// <Form.Label column sm={2}>

// Program start

// </Form.Label>

// <Col sm={5}>

// <Form.Control type="programstart" />

// </Col>

// </Form.Group>

// ​

// <Form.Group as={Row} className="mb-3" controlId="formHorizontaldeadline">

// <Form.Label column sm={2}>

// Program end

// </Form.Label>

// <Col sm={5}>

// <Form.Control type="programend" />

// </Col>

// </Form.Group>

// ​

// <Form.Group as={Row} className="mb-3" controlId="formHorizontaldeadline">

// <Form.Label column sm={2}>

// Organizers

// </Form.Label>

// <Col sm={5}>

// <Form.Control type="programend" />

// </Col>

// </Form.Group>

// ​

// <Form.Group as={Row} className="mb-3" controlId="formHorizontaldeadline">

// <Form.Label column sm={2}>

// Program end

// </Form.Label>

// <Col sm={5}>

// <Form.Control type="programend" />

// </Col>

// </Form.Group>

// ​

// ​

// <Form.Group as={Row} className="mb-3" controlId="formHorizontaldeadline">

// <Form.Label column sm={2}>

// Organizers

// </Form.Label>

// <Col sm={5}>

// <Form.Control type="organizers" />

// </Col>

// </Form.Group>

// ​

// <Form.Group as={Row} className="mb-3" controlId="formHorizontaldeadline">

// <Form.Label column sm={2}>

// Location

// </Form.Label>

// <Col sm={5}>

// <Form.Control type="location" />

// </Col>

// </Form.Group>

// ​

// ​

// <Form.Group className="mb-3" controlId="exampleForm.ControlTextarea3">

// <Form.Label>Eligibilities</Form.Label>

// <Col sm={5}>

// <Form.Control as="textarea" rows={3} />

// </Col>

// </Form.Group>

// ​

// <Form.Group as={Row} className="mb-3" controlId="formHorizontaldeadline">

// <Form.Label column sm={2}>

// Official contact E-mail

// </Form.Label>

// <Col sm={5}>

// <Form.Control type="e-mail" />

// </Col>

// </Form.Group>

// ​

// <Form.Group as={Row} className="mb-3" controlId="formHorizontaldeadline">

// <Form.Label column sm={2}>

// Person name

// </Form.Label>

// <Col sm={5}>

// <Form.Control type="personname" />

// </Col>

// </Form.Group>

// ​

// <Form.Group as={Row} className="mb-3" controlId="formHorizontaldeadline">

// <Form.Label column sm={2}>

// Person e-mail

// </Form.Label>

// <Col sm={5}>

// <Form.Control type="persone-mail" />

// </Col>

// </Form.Group>

// ​

// <fieldset>

// <Form.Group as={Row} className="mb-3" controlId="formHorizontaldeadline">

// <Form.Label column sm={2}>

// Featured image

// </Form.Label>

// <Col sm={5}>

// <Button variant="secondary">Upload image</Button>{' '}

// </Col>

// </Form.Group>

// </fieldset>

// ​

// ​

// ​

// ​

// ​

// ​

// ​

// <Form.Group as={Row} className="mb-3" controlId="formHorizontalCheck">

// <Col sm={{ span: 10, offset: 2 }}>

// <Form.Check label="Sure my details" />

// </Col>

// </Form.Group>

// ​

// <Form.Group as={Row} className="mb-3">

// <Col sm={{ span: 10, offset: 2 }}>

// <Button variant="secondary" size="lg">

// Post an opportunity

// </Button>

// </Col>

// </Form.Group>

// </Form> 
//         </div>
//     )
// }

import React from 'react'
 //import {Link} from 'react-router-dom';


import Carousel from 'react-bootstrap/Carousel';
import challenge from '../Photos/challenge.jpg';
import competition from '../Photos/competition.jpg';
import opportunity2 from '../Photos/opportunity2.jpg';
import DropdownButton from 'react-bootstrap/DropdownButton';
import Dropdown from 'react-bootstrap/Dropdown';
import Button from 'react-bootstrap/Button';
import StarfieldAnimation from 'react-starfield-animation'



export default function Home() {
    return (
        // <div className='container text-center home-banner'>
    <div className="body">
  
      <div >
      <Carousel fade>
  <Carousel.Item>
    <img
      className="d-block w-80"
      src={challenge}
      alt="First slide"
    />
    <Carousel.Caption>
      <h3>First slide label</h3>
      <p>Nulla vitae elit libero, a pharetra augue mollis interdum.</p>
    </Carousel.Caption>
  </Carousel.Item>
  <Carousel.Item>
    <img
      className="d-block w-80"
      src="holder.js/800x400?text=Second slide&bg=282c34"
      alt="Second slide"
    />

    <Carousel.Caption>
      <h3>Second slide label</h3>
      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
    </Carousel.Caption>
  </Carousel.Item>
  <Carousel.Item>
    <img
      className="d-block w-80"
      src="holder.js/800x400?text=Third slide&bg=20232a"
      alt="Third slide"
    />

    <Carousel.Caption>
      <h3>Third slide label</h3>
      <p>Praesent commodo cursus magna, vel scelerisque nisl consectetur.</p>
    </Carousel.Caption>
  </Carousel.Item>
</Carousel>
 
      </div>
<StarfieldAnimation
        style={{
          position: 'absolute',
          width: '100%',
          height: '100%'
        }}
      />
 < div className="row-drop">
   {/* <div className="col-lg-4"> */}
 <DropdownButton  title="Opportunities" className="drop1">
    <Dropdown.ItemText> Workshops </Dropdown.ItemText>
    <Dropdown.Item as="button"> Challenges</Dropdown.Item>
    <Dropdown.Item as="button"> Jobs </Dropdown.Item>
    <Dropdown.Item as="button"> Conferences </Dropdown.Item>
    </DropdownButton>
    {/* </div> */}
    
    {/* <div className="col-lg-4"> */}
    <DropdownButton  title="Categories" className="drop2" >
    <Dropdown.ItemText> School leavers </Dropdown.ItemText>
    <Dropdown.Item as="button"> Under graduates </Dropdown.Item>
    <Dropdown.Item as="button"> Graduates</Dropdown.Item>
    <Dropdown.Item as="button"> Job seekers </Dropdown.Item>
    </DropdownButton>
    {/* </div> */}
    <br/>
    {/* <div className= 'col-lg-4'> */}
    <Button className="btn btn-slide-bottom btn-slide-bottom--red" id="filter-button" style={{width: "150px"}}>
    <span>Explore</span>
    </Button> 
    {/* </div> */}

    </div>
     </div>
    );
}


{/* <Carousel style={{margin: "50px"}}>
<Carousel.Item>
  <img
    className="d-block"
    src={challenge}
    alt="First slide"
  />
  <Carousel.Caption>
    <h3 className="slide"> CHALLENGES </h3>
    <p className="slide"> Don't take every CHALLENGES as a problem , Take every problem as a challenge.</p>
  </Carousel.Caption>
</Carousel.Item>
<Carousel.Item>
  <img
    className="d-block"
    src={competition}
    alt="Second slide"
  />

  <Carousel.Caption>
    <h3 className="slide"> INTERNSHIPS </h3>
    <p className="slide"> The expert in anything was once a beginner</p>
  </Carousel.Caption>
</Carousel.Item>
<Carousel.Item>
  <img
    className="d-block"
    src={opportunity2}
    alt="Third slide"
  />

  <Carousel.Caption>
    <h3 className="slide"> COMPETITIONS </h3>
    <p className="slide"> COMPETITION makes us Faster. Collaboration makes us better </p>
  </Carousel.Caption>
</Carousel.Item>
</Carousel> */}
// import React from 'react'
import './css/browseOpp.css';
import './js/browseOpp';
import opp5 from '../Photos/opp5.jpg';
import DropdownButton from 'react-bootstrap/DropdownButton';
import Dropdown from 'react-bootstrap/Dropdown';
import { Link } from 'react-router-dom';

export default function Browseopp2() {
    return (
        <div>
            
        <header class="bg-dark py-1 mb-4">
            <div class="container px-4 px-lg-5 my-5">
                <div class="text-center text-white">
                    <h1 class="display-4 fw-bolder"> Browse Opportunities </h1>
                    <p class="lead fw-normal text-white-50 mb-0"> Opportunities don't happen, you create them</p>
                </div>
            </div>
        </header>

        <div className="row">

<div className= 'col-lg-3 filter-dropdown'>
<DropdownButton id="dropdown-item-button" title="Opportunity Category">
<Dropdown.ItemText> Workshops</Dropdown.ItemText>
<Dropdown.Item as="button"> Conferences </Dropdown.Item>
<Dropdown.Item as="button"> Jobs </Dropdown.Item>
<Dropdown.Item as="button"> Challenges </Dropdown.Item>
</DropdownButton>
</div>

<div className= 'col-lg-3 filter-dropdown'>
<DropdownButton id="dropdown-item-button" title="Customer Category">
<Dropdown.ItemText> School leavers </Dropdown.ItemText>
<Dropdown.Item as="button"> Under graduates </Dropdown.Item>
<Dropdown.Item as="button"> Graduates </Dropdown.Item>

</DropdownButton>
</div>

<div className= 'col-lg-3 filter-dropdown'>
<DropdownButton id="dropdown-item-button" title="Location">
<Dropdown.ItemText>Dropdown item text</Dropdown.ItemText>
<Dropdown.Item as="button">Action</Dropdown.Item>
<Dropdown.Item as="button">Another action</Dropdown.Item>
<Dropdown.Item as="button">Something else</Dropdown.Item>
</DropdownButton>
</div>

<div className= 'col-lg-3 filter-dropdown'>
<DropdownButton id="dropdown-item-button" title="Deadline">
<Dropdown.ItemText>Dropdown item text</Dropdown.ItemText>
<Dropdown.Item as="button">Action</Dropdown.Item>
<Dropdown.Item as="button">Another action</Dropdown.Item>
<Dropdown.Item as="button">Something else</Dropdown.Item>
</DropdownButton>
</div>
</div>   

<div className="row">
<div className= 'col-lg-3'>
<div class="card-footer p-4 pt-0 border-top-0 bg-transparent">
                                <div class="text-center"><a class="btn btn-outline-dark mt-auto" href="#"> Explore </a></div>
                            </div>
</div>

<div className= 'col-lg-3'>
<div class="card-footer p-4 pt-0 border-top-0 bg-transparent">
                                <div class="text-center"><a class="btn btn-outline-dark mt-auto" href="#"> Reset filter</a></div>
                            </div>
</div>
</div>
       
        <section class="py-5">
            <div class="container px-4 px-lg-5 mt-5">
                <div class="row gx-4 gx-lg-5 row-cols-2 row-cols-md-3 row-cols-xl-4 justify-content-center">
                <div class="col mb-5">
                        <div class="card h-100">
                           
                            <img class="card-img-top" src={opp5} alt="..." />
                            
                            <div class="card-body p-4">
                                <div class="text-center">
                                    
                                    <h5 class="fw-bolder"> Opportunity 1</h5>
                                    <div class="small text-muted">January 1, 2021</div>
                                   
                                </div>
                            </div>
                           
                            <div class="card-footer p-4 pt-0 border-top-0 bg-transparent">
                                <div class="text-center"><a class="btn btn-outline-dark mt-auto" href="/Singleopp">Explore</a></div>
                            </div>
                        </div>
                    </div>
                    <div class="col mb-5">
                        <div class="card h-100">
                           
                            <img class="card-img-top" src={opp5} alt="..." />
                            
                            <div class="card-body p-4">
                                <div class="text-center">
                                    
                                    <h5 class="fw-bolder"> Opportunity 2</h5>
                                    <div class="small text-muted">January 1, 2021</div>
                                   
                                </div>
                            </div>
                           
                            <div class="card-footer p-4 pt-0 border-top-0 bg-transparent">
                                <div class="text-center"><a class="btn btn-outline-dark mt-auto" href="/Singleopp">Explore</a></div>
                            </div>
                        </div>
                    </div>
                    <div class="col mb-5">
                        <div class="card h-100">
                           
                            <img class="card-img-top" src={opp5} alt="..." />
                            
                            <div class="card-body p-4">
                                <div class="text-center">
                                    
                                    <h5 class="fw-bolder"> Opportunity 3</h5>
                                    <div class="small text-muted">January 1, 2021</div>
                                   
                                </div>
                            </div>
                           
                            <div class="card-footer p-4 pt-0 border-top-0 bg-transparent">
                                <div class="text-center"><a class="btn btn-outline-dark mt-auto" href="/Singleopp">Explore</a></div>
                            </div>
                        </div>
                    </div>
                    <div class="col mb-5">
                        <div class="card h-100">
                           
                            <img class="card-img-top" src={opp5} alt="..." />
                            
                            <div class="card-body p-4">
                                <div class="text-center">
                                    
                                    <h5 class="fw-bolder"> Opportunity 4</h5>
                                    <div class="small text-muted">January 1, 2021</div>
                                   
                                </div>
                            </div>
                           
                            <div class="card-footer p-4 pt-0 border-top-0 bg-transparent">
                                <div class="text-center"><a class="btn btn-outline-dark mt-auto" href="/Singleopp">Explore</a></div>
                            </div>
                        </div>
                    </div>
                    <div class="col mb-5">
                        <div class="card h-100">
                           
                            <img class="card-img-top" src={opp5} alt="..." />
                            
                            <div class="card-body p-4">
                                <div class="text-center">
                                    
                                    <h5 class="fw-bolder"> Opportunity 5</h5>
                                    <div class="small text-muted">January 1, 2021</div>
                                   
                                </div>
                            </div>
                           
                            <div class="card-footer p-4 pt-0 border-top-0 bg-transparent">
                                <div class="text-center"><a class="btn btn-outline-dark mt-auto" href="/Singleopp">Explore</a></div>
                            </div>
                        </div>
                    </div>
                    <div class="col mb-5">
                        <div class="card h-100">
                           
                            <img class="card-img-top" src={opp5} alt="..." />
                            
                            <div class="card-body p-4">
                                <div class="text-center">
                                    
                                    <h5 class="fw-bolder"> Opportunity 6</h5>
                                    <div class="small text-muted">January 1, 2021</div>
                                   
                                </div>
                            </div>
                           
                            <div class="card-footer p-4 pt-0 border-top-0 bg-transparent">
                                <div class="text-center"><a class="btn btn-outline-dark mt-auto" href="/Singleopp">Explore</a></div>
                            </div>
                        </div>
                    </div>
                    <div class="col mb-5">
                        <div class="card h-100">
                           
                            <img class="card-img-top" src={opp5} alt="..." />
                            
                            <div class="card-body p-4">
                                <div class="text-center">
                                    
                                    <h5 class="fw-bolder"> Opportunity 7</h5>
                                    <div class="small text-muted">January 1, 2021</div>
                                   
                                </div>
                            </div>
                           
                            <div class="card-footer p-4 pt-0 border-top-0 bg-transparent">
                                <div class="text-center"><a class="btn btn-outline-dark mt-auto" href="/Singleopp">Explore</a></div>
                            </div>
                        </div>
                    </div>
                    <div class="col mb-5">
                        <div class="card h-100">
                           
                            <img class="card-img-top" src={opp5} alt="..." />
                            
                            <div class="card-body p-4">
                                <div class="text-center">
                                    
                                    <h5 class="fw-bolder"> Opportunity 8 </h5>
                                    <div class="small text-muted">January 1, 2021</div>
                                   
                                </div>
                            </div>
                           
                            <div class="card-footer p-4 pt-0 border-top-0 bg-transparent">
                                <div class="text-center"><a class="btn btn-outline-dark mt-auto" href="/Singleopp">Explore</a></div>
                            </div>
                        </div>
                    </div>
                    
                </div>
            </div>
        </section>
        
      
        </div>
    )
}

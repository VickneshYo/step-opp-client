import React from 'react'
import Form from 'react-bootstrap/Form'
import Button from 'react-bootstrap/Button';
import '../App.css';
import FloatingLabel from 'react-bootstrap/FloatingLabel';

export default function Contact() {
    return (
        <div > 
              <div>
      <h1 className="header"><b> Contact Us </b></h1>
    </div>
    <Form className="contact-us" align="center">

    <Form.Group className="mb-3">

    <Form.Label id="label"> Full Name </Form.Label>
    <Form.Control type="email" placeholder="Enter your name"  />
    {/* <Form.Text className="text-muted">
      We'll never share your email with anyone else.
    </Form.Text> */}

    <Form.Label id="label">Email address</Form.Label>
    <Form.Control type="email" placeholder="Enter email" />
    {/* <Form.Text className="text-muted">
      We'll never share your email with anyone else.
    </Form.Text> */}

    <Form.Label id="label"> Type </Form.Label>
    <Form.Control type="email" placeholder="Category" />

    <Form.Label id="label">Comments</Form.Label>
    <Form.Control
      as="textarea"
      placeholder="Leave a comment here"
      style={{ height: '100px' }}
    />
 
    <Form.Check type="checkbox" label="Check me out"  />
    <Button variant="primary" type="submit" className="mb-3">
    Submit
  </Button>

  </Form.Group>

</Form>
            
        </div>
    )
}






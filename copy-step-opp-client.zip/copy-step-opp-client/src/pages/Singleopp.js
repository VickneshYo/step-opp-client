import React from 'react';
import Card from 'react-bootstrap/Card';
import Button from 'react-bootstrap/Button';
import competition from '../Photos/competition.jpg'
import {BiCalendar} from 'react-icons/bi';
import {BiTimeFive} from 'react-icons/bi';
import {FaRegBell} from 'react-icons/fa';
import {BiCategory} from 'react-icons/bi';
import {BiLocationPlus} from 'react-icons/bi';
import {FaSistrix} from "react-icons/fa";
import {FcProcess} from 'react-icons/fc';
import Tab from 'react-bootstrap/Tab';
import Nav from 'react-bootstrap/Nav';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';

import Form from 'react-bootstrap/Form';
import { FloatingLabel } from 'react-bootstrap';


export default function Singleopp() {
    return (
        <div>
              
             
       <div>        
      <h1 className="header"><b> Single Opportunity </b></h1>
      <h2 align="center" className="single1"><b> COMPETITION </b></h2>
    </div>
    <div className="row">
    <div className="col-sm">
    {/* <Button variant="secondary" size="lg" active >
     Category
  </Button>
  <br/> */}
  <Button className="btn btn-slide-bottom btn-slide-bottom--red" id="filter-button" style={{width: "150px"}}>
  <BiCategory/>
    <span>Category</span>
    </Button> 
    <br/>
    
    <Button className="btn btn-slide-bottom btn-slide-bottom--red" id="filter-button" style={{width: "150px"}}>
    <BiCalendar/>
    <span>Deadline
    
    </span>
    </Button> 
    <br/>
    <Button className="btn btn-slide-bottom btn-slide-bottom--red" id="filter-button" style={{width: "150px"}}>
    <BiTimeFive/>
    <span> Time left</span>
    </Button> 
    <br/>
    <Button className="btn btn-slide-bottom btn-slide-bottom--red" id="filter-button" style={{width: "150px"}}>
  <BiLocationPlus/>
    <span> Location</span>
    </Button>
    <br/>
 
   <bell/>
</div>
<div className="col-sm">

  <Card style={{ width: '25rem' }} className="opp-img">
  <Card.Img variant="top" src={competition} />
  <Card.Body>
    <Card.Title>Competition</Card.Title>
    <Card.Text>
      Some quick example text to build on the card title and make up the bulk of
      the card's content.
    </Card.Text>
   
    <Button variant="primary" className="btn-single"><FaSistrix/> EXPLORE </Button>
  </Card.Body>
</Card>


</div>  
 </div> 

 <br/>
 <Button variant="secondary" className="btn-sub"> SUBSCRIBE  <FaRegBell/></Button>
 

 <Tab.Container id="left-tabs-example" defaultActiveKey="first">
  <Row>
    <Col sm={3}>
      <Nav variant="pills" className="flex-column">
        <Nav.Item>
          <Nav.Link eventKey="first"> Apply for competition </Nav.Link>
        </Nav.Item>
        <Nav.Item>
          <Nav.Link eventKey="second"> Benifits </Nav.Link>
        </Nav.Item>
        <Nav.Item>
          <Nav.Link eventKey="third"> Eligibilities </Nav.Link>
        </Nav.Item>
        
          </Nav>
          </Col>
          <Col sm={9}>
      <Tab.Content>
        <Tab.Pane eventKey="first">
          {/* <Sonnet /> */}
          Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et
           quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et 
        </Tab.Pane>
        <Tab.Pane eventKey="second">
        est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, 
        quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?"
        </Tab.Pane>
        <Tab.Pane eventKey="third">

    Commonwealth100 is open to young people aged 18 and above
    You may be at the beginning of your careers or in Higher or Further education

        </Tab.Pane>
        </Tab.Content>
    </Col>
  </Row>
</Tab.Container>

<br/>

<>
  
  <FloatingLabel controlId="floatingTextarea2" label="Application Process">
  
    <Form.Control
      as="textarea"
      placeholder="Leave a comment here"
      style={{ height: '100px' }}
    />
   
  </FloatingLabel>
</>

 
        </div>
    )
}
